"""Same regression assertion before and after the isolated reference correction."""
import csv
import os
from collections import defaultdict
from pathlib import Path
import unittest


class ActualInventoryRegression(unittest.TestCase):
    def test_sales_do_not_consume_same_session_purchases(self):
        root = Path(os.environ['NATIVE_ACCOUNT'])
        holdings = defaultdict(int)
        sellable = {}
        session = None
        violations = []
        with (root / 'trades.csv').open() as f:
            for row in csv.DictReader(f):
                day, symbol = row['date'], row['symbol']
                if day != session:
                    session = day
                    sellable = dict(holdings)
                qty = int(float(row['quantity']))
                self.assertGreater(qty, 0)
                if row['side'] == 'BUY':
                    holdings[symbol] += qty
                else:
                    available = sellable.get(symbol, 0)
                    if qty > available:
                        violations.append((day, symbol, qty, available, row['reason']))
                    sellable[symbol] = available - qty
                    holdings[symbol] -= qty
                self.assertGreaterEqual(holdings[symbol], 0)
        self.assertEqual(violations, [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
