"""Read-only independent cash, inventory, NAV and comparison reconciliation."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from techquant.data import load_market


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(root, market):
    settings = json.loads((root / 'settings.json').read_text())
    fills = pd.read_csv(root / 'trades.csv', float_precision='round_trip', parse_dates=['date'])
    equity = pd.read_csv(root / 'equity.csv', float_precision='round_trip', index_col=0, parse_dates=True)
    cash, positions, costs = 2_000_000., defaultdict(int), {}
    rows, violations, cash_errors, holdings_errors = [], [], [], []
    daily_file = root / 'inventory_audit.json'
    recorded = {}
    if daily_file.exists():
        recorded = {pd.Timestamp(row['date']): row for row in json.loads(daily_file.read_text())['daily']}
    total_fees = 0.
    grouped = {d: frame for d, frame in fills.groupby('date', sort=False)}
    for date in equity.index:
        opening = dict(positions)
        for row in grouped.get(date, pd.DataFrame()).itertuples(index=False):
            symbol, qty, price = row.symbol, int(row.quantity), float(row.price)
            assert qty == row.quantity and qty > 0 and np.isfinite(price) and price > 0
            notional = qty * price
            if row.side == 'BUY':
                fees = notional * settings['fee']
                cash -= notional + fees
                old = positions[symbol]
                costs[symbol] = (costs.get(symbol, 0.) * old + notional) / (old + qty)
                positions[symbol] += qty
            else:
                assert row.side == 'SELL' and qty <= positions[symbol]
                available = opening.get(symbol, 0)
                if qty > available:
                    violations.append(dict(date=str(date.date()), symbol=symbol,
                                           quantity=qty, available=available, reason=row.reason))
                opening[symbol] = available - qty
                fees = notional * (settings['fee'] + settings['stamp_tax'])
                cash += notional - fees
                positions[symbol] -= qty
            total_fees += fees
        nav = cash
        for symbol, qty in positions.items():
            if qty:
                close = float(market.frames[symbol].loc[date, 'close'])
                nav += qty * (close if np.isfinite(close) else costs[symbol])
        actual = {s: q for s, q in positions.items() if q}
        if recorded:
            cash_errors.append(abs(cash - recorded[date]['cash']))
            if actual != recorded[date]['holdings']:
                holdings_errors.append(str(date))
        rows.append(dict(date=str(date.date()), cash=cash, nav=nav,
                         reported_nav=float(equity.loc[date, 'nav']), holdings=actual))
    computed = np.array([row['nav'] for row in rows])
    expected = equity.nav.to_numpy()
    np.testing.assert_allclose(computed, expected, rtol=1e-12, atol=1e-8)
    assert not holdings_errors and (not cash_errors or max(cash_errors) < 1e-7)
    windows = {}
    for start in ('2026-06-22', '2026-07-01'):
        part = equity.loc[start:'2026-08-31', 'nav']
        prior = equity.index.get_loc(part.index[0]) - 1
        base = equity.nav.iloc[prior] if prior >= 0 else 2_000_000.
        path = np.r_[base, part.to_numpy()]
        windows[start] = dict(return_fraction=float(path[-1] / base - 1),
                             local_max_drawdown=float((1 - path / np.maximum.accumulate(path)).max()))
    summary = json.loads((root / 'summary.json').read_text())
    return dict(sessions=len(equity), fills=len(fills), inventory_violations=violations,
                wealth=summary['wealth'], max_drawdown=summary['max_drawdown'],
                max_nav_abs_error=float(np.max(np.abs(computed - expected))),
                max_trace_cash_abs_error=max(cash_errors, default=None),
                trace_holdings_mismatches=holdings_errors, total_fees=total_fees,
                minimum_cash=min(r['cash'] for r in rows), final_holdings=rows[-1]['holdings'],
                final_cash=rows[-1]['cash'], windows=windows,
                economic_file_sha256={f: digest(root/f) for f in ('equity.csv','trades.csv','settings.json')}), rows


def main():
    root, repo, inputs = map(Path, sys.argv[1:])
    catalog = json.loads((repo/'research/catalog.json').read_text())
    market = load_market(inputs/'market', supplement=inputs/'supplement', sectors=catalog['sectors'])
    assert market.fingerprint() == 'd9ded1d933f292933aa09145bc36a5696421c43dbf266fce018a34ef0b9f3f9b'
    result = {}
    for mode in ('original','corrected'):
        result[mode], rows = audit(root/mode, market)
        (root/'checks'/f'{mode}-reconciled-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
    original = pd.read_csv(root/'original/equity.csv',index_col=0,parse_dates=True,float_precision='round_trip')
    corrected = pd.read_csv(root/'corrected/equity.csv',index_col=0,parse_dates=True,float_precision='round_trip')
    mismatch = original.nav != corrected.nav
    first = str(mismatch[mismatch].index[0].date())
    assert first == '2025-04-28'
    assert len(result['original']['inventory_violations']) == 1
    assert not result['corrected']['inventory_violations']
    assert (root/'original/settings.json').read_bytes() == (root/'corrected/settings.json').read_bytes()
    result['difference'] = dict(
        first_equity_difference=first,
        earlier_equity_prefix_exact=True,
        settings_byte_identical=True,
        wealth_multiple=result['corrected']['wealth']-result['original']['wealth'],
        terminal_wealth_relative=result['corrected']['wealth']/result['original']['wealth']-1,
        final_cash=result['corrected']['final_cash']-result['original']['final_cash'],
        max_drawdown_percentage_points=100*(result['corrected']['max_drawdown']-result['original']['max_drawdown']),
        fees=result['corrected']['total_fees']-result['original']['total_fees'],
    )
    result['scope'] = 'One fixed inventory-only reference correction, not uniform execution or quant economic acceptance'
    (root/'checks/reconciliation.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
