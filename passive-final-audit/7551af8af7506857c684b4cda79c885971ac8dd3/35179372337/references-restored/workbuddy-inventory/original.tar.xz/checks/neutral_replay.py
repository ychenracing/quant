"""Neutral equivalence fixture: AST hooks present, inventory intervention disabled.

This is a correctness control, not an additional economic strategy candidate.
"""
import hashlib
import json
from pathlib import Path
import sys
from research import native
from research.native_inventory import Inventory, corrected_module


class NeutralInventory(Inventory):
    def quote(self, symbol, requested, held, reason, token=None):
        return min(int(requested), int(held))

    def record(self, trade):
        _, symbol, side, _, qty, _ = trade
        self.expected[symbol] = self.expected.get(symbol, 0) + (qty if side == 'BUY' else -qty)


def loader(name, file):
    value = corrected_module(name, file)
    value._Inventory = NeutralInventory
    return value


native.module = loader
status = native.main()
assert status == 0
output = Path(sys.argv[sys.argv.index('--output') + 1])
original = output.parent / 'original'
files = ('equity.csv', 'native_frame.csv', 'trades.csv', 'settings.json')
checks = {name: hashlib.sha256((output / name).read_bytes()).hexdigest()
          for name in files}
assert all((output / name).read_bytes() == (original / name).read_bytes() for name in files)
identity = json.loads((output / 'identity.json').read_text())
identity['classification'] = 'NEUTRAL_AST_EQUIVALENCE_DIAGNOSTIC'
identity['neutral_fixture_sha256'] = native.file_hash(Path(__file__))
identity['adapter_sha256'] = native.file_hash(Path(sys.modules[corrected_module.__module__].__file__))
native.write_json(output / 'identity.json', identity)
native.write_json(output / 'manifest.json', {p.name: native.file_hash(p) for p in output.iterdir()
                                           if p.name != 'manifest.json'})
native.write_json(output.parent / 'checks' / 'neutral-equivalence.json', {
    'all_four_files_byte_identical': True, 'file_sha256': checks,
    'sessions': 896, 'fills': 107,
    'scope': 'AST hooks with neutral inventory: exact control, not an economic treatment',
})
