# Inventory-only native comparison recovery

Continue original quant PR #1 from live refs. This fixed comparison has completed; do not rerun it merely because a new session started. It is not a production strategy candidate. Both closed economic-hypothesis budgets remain unchanged.

Implementation is research/expectation-learning at6c25731bfbad5149c0f8144423883edb6247ef76, tree2fcd1232dee08930372c8aedfc7b3758f05bdeb2. Two new files only: research/native_inventory.py and research/test_native_inventory.py. Production code, policy parameters, frozen selectors, workflows and original PR head/main were not changed. No private source is contained in this evidence payload or added to quant.

The source is recoverable from GitHub. Offline-correctness run34931912796 succeeded; its source-verification artifact10381209387 is a convenient transport (ZIP metadata digest b0cc543c5312a361bb30f45043a9847ddecc0f3625959928a4a4990fedd62c83). This artifact's bytes were not downloaded in this iteration; verify them when using it. Do not confuse source verification with the locally executed native comparison.

Frozen inputs can be recovered from quant run34794779702/artifact10329173115. Its ZIP digest a87e191252da3906550c8db6c74993124666de431a9583721717b2c5249bbb14 and concatenated evidence.tar.gz digest6f7864e8f60001790806dcedb2fb7abc5960fb992c936ee9ea2be02069f3f353 were verified. Only inputs/identity/manifests were extracted this iteration; do not claim a fresh6048-member verification. The complete34-name896-session market fingerprint is d9ded1d933f292933aa09145bc36a5696421c43dbf266fce018a34ef0b9f3f9b.

Private reference source stays in the authorized trades repository. Frozen reference commit5575d1b1b79fab405b92cfb7d164c7054a8bd826; the executed workbuddy file has Git blob e19e611cd332e7a01c0f8677e0ae60600b295c6d. The unchanged file was recovered from private run34135770719/artifact10023909983, ZIP digest514c79ece6f74d56e0a461376d52a490103d58883fbdef233fdbb372a6552064. Use the private GitHub connection, never publish that source to quant.

## Retained original and corrected results

`original/` contains the unchanged control recovery: wealth20.221072996623576,107 fills, one same-session inventory violation. `neutral/` contains the instrumentation-equivalence fixture: all four economic files are byte-identical to original. `corrected/` contains the one fixed inventory correction: wealth20.81972538210324,109 fills, zero opening-inventory violations, no outstanding protective quantity. All cover2023-01-03 through2026-09-11,896 sessions, initial cash2000000 and the unchanged common-five/profile-b settings.

The inventory correction defers52100 economic units of sz300502 from the2025-04-28 close hard-limit sale to2025-04-29 native opening execution. The intended hard-limit flat reset waits for actual flat clearance. Its old-inventory sale capacity, partial fills, fees, outstanding quantities, terminal marking and non-intervention paths are tested. This does not change the native risk policy into quant's risk policy.

`checks/` retains the actual RED and GREEN inventory regression,21 local inventory/private-helper tests,2 input-identity tests, the neutral-fixture code and equality result, independent cash/NAV reconciliation code and both full reconstructed daily ledgers. Maximum reconstructed NAV absolute error is7.450580596923828e-09; the corrected trace cash error and holdings mismatches are zero. Reference files and frozen settings were unchanged. The first differing NAV date is2025-04-28; earlier NAVs are exactly equal.

## Remaining work, not silently accepted

This fixes inventory alone. Native same-session ATR/closing-information timing, intraday rules, price availability and sell liquidity, fee differences, native drawdown resets, terminal assumptions and qfq economic-unit/corporate-action accounting remain unnormalized. Four-reference execution-equivalent comparison remains incomplete. The result is not an updated official quant target, a proven best reference, or evidence that quant's production returns improved. Original economic acceptance remains NOT_MET; no main merge is permitted.

The next independently actionable work is to define and reconcile the remaining reference information/execution differences using the original causal next-session contract and preserved traces, then complete the still-missing same-condition reference comparison. Do not open a new trading hypothesis, tune adjacent parameters, or reset either closed budget under a correctness label. Before new economic research, require genuinely new evidence and prospective boundaries under valid authorization. Reuse this completed inventory result; do not run a final economic matrix on a rejected quant treatment.

## Commands (only when a justified replay is needed)

Run in an isolated exact source checkout with Python3.13.5/numpy2.3.5/pandas2.2.3, PYTHONPATH=src:., OPENBLAS_NUM_THREADS=1, OMP_NUM_THREADS=1, QUANT_SOURCE_COMMIT set to the actual source SHA. Set DATA to recovered evidence/inputs and REF to an authorized read-only private checkout.

    python -m research.native_inventory --reference workbuddy --reference-root "$REF" --data "$DATA/market" --supplement "$DATA/supplement" --indices "$DATA/indices" --pool chatgpt_5 --output <new-immutable-directory>
    QUANT_NATIVE_REFERENCE="$REF/workbuddy/track_trend/quant_ai.py" python -m unittest research.test_native_inventory -v
    NATIVE_ACCOUNT=<recovered-corrected-directory> python checks/test_actual_inventory.py
    python checks/reconcile.py <recovered-payload-root> <exact-source-root> "$DATA"

The first two control/neutral replays used parent source32304314270586d078d527aa2860aab78a09f613 plus the explicitly hashed new adapter fixture. The corrected replay used6c25731bfbad5149c0f8144423883edb6247ef76 after remote tree readback. Keep these identities as recorded; do not relabel old executions as runs at the later commit. Reconciliation scripts write derived files and should be run on a copy, never over sealed evidence.
