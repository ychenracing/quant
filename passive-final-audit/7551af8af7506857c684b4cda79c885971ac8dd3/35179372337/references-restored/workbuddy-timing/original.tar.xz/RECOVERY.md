# Recovery

This payload contains the single fixed WorkBuddy common-five timing+inventory corrected account for quant research source `89cf5c47188bde63d6c09a2c7d9207e3178b9904`. It contains no private reference source. Recover the public comparator code from that quant commit and the private reference only through the authorized frozen `ychenracing/trades@5575d1b1b79fab405b92cfb7d164c7054a8bd826` identity.

Verify `MANIFEST.json` before interpreting any files. `output/` is the exact measured account. `checks/reconciliation.json` is an independent full-ledger replay against frozen market data; `checks/timing-reconciled-ledger.json` is the 896-session reconstructed ledger. Test/run logs are raw local outputs. This result is correctness-only and is not quant economic acceptance.
